# Scripts Directory

This directory contains all PowerShell scripts for the Microsoft Office Management Tools project.

## 📁 Script Files

### Core Scripts
- **`office-activator.ps1`** - Office management and administration script
- **`powershell-educational-examples.ps1`** - Safe educational PowerShell examples
- **`test-windows-compatibility.ps1`** - Windows compatibility test script

### Usage Examples

```powershell
# Office Management
.\office-activator.ps1 -Action CheckStatus

# Educational Examples
.\powershell-educational-examples.ps1 -Example All

# Compatibility Test
.\test-windows-compatibility.ps1
```

## 🔧 Script Requirements

- Windows operating system
- PowerShell 5.1 or later
- Microsoft Office (for Office management features)
- Appropriate permissions for system operations

## 📚 Educational Value

These scripts demonstrate:
- PowerShell scripting techniques
- Windows administration methods
- Office management automation
- Security best practices
- Safe remote operations
- Process management
- Registry operations
