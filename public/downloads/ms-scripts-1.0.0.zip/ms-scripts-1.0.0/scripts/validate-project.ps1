# Project Validation Script
# Validates that the project is ready for GitHub

Write-Host "Project Validation for GitHub Readiness" -ForegroundColor Cyan
Write-Host "=" * 50 -ForegroundColor Cyan

# Check 1: Project Structure
Write-Host "`n1. Checking Project Structure..." -ForegroundColor Yellow
$requiredDirs = @("scripts", "docs", "examples", "tests", "assets")
$missingDirs = @()

foreach ($dir in $requiredDirs) {
    if (Test-Path $dir) {
        Write-Host "✅ $dir/ directory exists" -ForegroundColor Green
    } else {
        Write-Host "❌ $dir/ directory missing" -ForegroundColor Red
        $missingDirs += $dir
    }
}

# Check 2: Required Files
Write-Host "`n2. Checking Required Files..." -ForegroundColor Yellow
$requiredFiles = @(
    "README.md",
    "LICENSE",
    "project.json",
    ".gitignore",
    "office-activator.exe",
    "scripts/office-activator.ps1",
    "scripts/powershell-educational-examples.ps1",
    "scripts/test-windows-compatibility.ps1",
    "docs/CHANGELOG.md",
    "docs/CONTRIBUTING.md",
    "docs/EDUCATIONAL_GUIDE.md",
    "docs/GITHUB_COMPLIANCE.md"
)

$missingFiles = @()
foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        Write-Host "✅ $file exists" -ForegroundColor Green
    } else {
        Write-Host "❌ $file missing" -ForegroundColor Red
        $missingFiles += $file
    }
}

# Check 3: Script Syntax Validation
Write-Host "`n3. Validating PowerShell Scripts..." -ForegroundColor Yellow
$psScripts = @(
    "scripts/office-activator.ps1",
    "scripts/powershell-educational-examples.ps1",
    "scripts/test-windows-compatibility.ps1"
)

foreach ($script in $psScripts) {
    if (Test-Path $script) {
        try {
            $null = Get-Content $script -ErrorAction Stop
            Write-Host "✅ $script syntax valid" -ForegroundColor Green
        } catch {
            Write-Host "❌ $script syntax error: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
}

# Check 4: Documentation Links
Write-Host "`n4. Checking Documentation Links..." -ForegroundColor Yellow
$readmeContent = Get-Content "README.md" -Raw
if ($readmeContent -match "scripts/") {
    Write-Host "✅ README.md references correct script paths" -ForegroundColor Green
} else {
    Write-Host "⚠️  README.md may have incorrect script paths" -ForegroundColor Yellow
}

# Check 5: GitHub Compliance
Write-Host "`n5. Checking GitHub Compliance..." -ForegroundColor Yellow
if (Test-Path "docs/GITHUB_COMPLIANCE.md") {
    Write-Host "✅ GitHub compliance document exists" -ForegroundColor Green
} else {
    Write-Host "❌ GitHub compliance document missing" -ForegroundColor Red
}

if (Test-Path "LICENSE") {
    Write-Host "✅ LICENSE file exists" -ForegroundColor Green
} else {
    Write-Host "❌ LICENSE file missing" -ForegroundColor Red
}

# Check 6: Educational Content
Write-Host "`n6. Checking Educational Content..." -ForegroundColor Yellow
if (Test-Path "scripts/powershell-educational-examples.ps1") {
    Write-Host "✅ Educational examples script exists" -ForegroundColor Green
} else {
    Write-Host "❌ Educational examples script missing" -ForegroundColor Red
}

if (Test-Path "docs/EDUCATIONAL_GUIDE.md") {
    Write-Host "✅ Educational guide exists" -ForegroundColor Green
} else {
    Write-Host "❌ Educational guide missing" -ForegroundColor Red
}

# Summary
Write-Host "`n" -NoNewline
Write-Host "=" * 50 -ForegroundColor Cyan
Write-Host "VALIDATION SUMMARY" -ForegroundColor Cyan
Write-Host "=" * 50 -ForegroundColor Cyan

if ($missingDirs.Count -eq 0 -and $missingFiles.Count -eq 0) {
    Write-Host "🎉 PROJECT IS READY FOR GITHUB!" -ForegroundColor Green
    Write-Host "✅ All required files and directories exist" -ForegroundColor Green
    Write-Host "✅ Project structure is professional" -ForegroundColor Green
    Write-Host "✅ Documentation is complete" -ForegroundColor Green
    Write-Host "✅ GitHub compliance is ensured" -ForegroundColor Green
} else {
    Write-Host "⚠️  PROJECT NEEDS ATTENTION:" -ForegroundColor Yellow
    if ($missingDirs.Count -gt 0) {
        Write-Host "Missing directories: $($missingDirs -join ', ')" -ForegroundColor Red
    }
    if ($missingFiles.Count -gt 0) {
        Write-Host "Missing files: $($missingFiles -join ', ')" -ForegroundColor Red
    }
}

Write-Host "`n📋 Next Steps:" -ForegroundColor Yellow
Write-Host "1. Review any issues above" -ForegroundColor White
Write-Host "2. Fix any missing files or directories" -ForegroundColor White
Write-Host "3. Test scripts in Windows environment" -ForegroundColor White
Write-Host "4. Push to GitHub repository" -ForegroundColor White
