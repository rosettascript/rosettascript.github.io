# Microsoft Office Management Script
# Educational and Development Use Only
# Version: 1.0.0
# Author: Educational Project
# Description: PowerShell script demonstrating Office management techniques for educational purposes

<#
.SYNOPSIS
    Microsoft Office Management Script for Educational Use

.DESCRIPTION
    This script demonstrates PowerShell techniques for Office management in educational
    and development environments. It shows legitimate administrative tasks and
    PowerShell scripting patterns.

.PARAMETER Action
    The action to perform: CheckStatus, GetInfo, or ListProducts

.PARAMETER Product
    The Office product to check (optional)

.EXAMPLE
    .\office-activator.ps1 -Action CheckStatus
    Checks the status of Office products on the system.

.EXAMPLE
    .\office-activator.ps1 -Action GetInfo -Product "Microsoft Word"
    Gets detailed information about Microsoft Word.

.NOTES
    - This script is for educational purposes only
    - Demonstrates legitimate PowerShell techniques
    - Shows proper error handling and logging
    - Educational examples of Office management

.LINK
    https://docs.microsoft.com/en-us/powershell/
#>

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("CheckStatus", "GetInfo", "ListProducts", "GetVersion")]
    [string]$Action,
    
    [Parameter(Mandatory=$false)]
    [string]$Product
)

# Function to check Office installation status
function Get-OfficeStatus {
    Write-Host "Checking Microsoft Office installation status..." -ForegroundColor Green
    
    try {
        # Check for Office installation using WMI
        $officeProducts = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "*Microsoft Office*" }
        
        if ($officeProducts) {
            Write-Host "Office products found:" -ForegroundColor Yellow
            foreach ($product in $officeProducts) {
                Write-Host "  - $($product.Name) (Version: $($product.Version))" -ForegroundColor Cyan
            }
        } else {
            Write-Host "No Microsoft Office products detected." -ForegroundColor Red
        }
    }
    catch {
        Write-Host "Error checking Office status: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Function to get detailed Office information
function Get-OfficeInfo {
    param([string]$ProductName)
    
    Write-Host "Getting detailed information for: $ProductName" -ForegroundColor Green
    
    try {
        $product = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "*$ProductName*" }
        
        if ($product) {
            Write-Host "Product Information:" -ForegroundColor Yellow
            Write-Host "  Name: $($product.Name)" -ForegroundColor Cyan
            Write-Host "  Version: $($product.Version)" -ForegroundColor Cyan
            Write-Host "  Vendor: $($product.Vendor)" -ForegroundColor Cyan
            Write-Host "  Install Date: $($product.InstallDate)" -ForegroundColor Cyan
        } else {
            Write-Host "Product '$ProductName' not found." -ForegroundColor Red
        }
    }
    catch {
        Write-Host "Error getting product information: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Function to list all Office products
function Get-OfficeProducts {
    Write-Host "Listing all Microsoft Office products..." -ForegroundColor Green
    
    try {
        $products = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "*Microsoft Office*" }
        
        if ($products) {
            $products | ForEach-Object {
                Write-Host "Product: $($_.Name)" -ForegroundColor Cyan
                Write-Host "  Version: $($_.Version)" -ForegroundColor White
                Write-Host "  Vendor: $($_.Vendor)" -ForegroundColor White
                Write-Host "  Install Location: $($_.InstallLocation)" -ForegroundColor White
                Write-Host "---" -ForegroundColor Gray
            }
        } else {
            Write-Host "No Microsoft Office products found." -ForegroundColor Red
        }
    }
    catch {
        Write-Host "Error listing products: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Function to get Office version information
function Get-OfficeVersion {
    Write-Host "Getting Office version information..." -ForegroundColor Green
    
    try {
        # Check registry for Office version
        $officeKey = "HKLM:\SOFTWARE\Microsoft\Office"
        if (Test-Path $officeKey) {
            $versions = Get-ChildItem $officeKey | Where-Object { $_.Name -match "\d+\.\d+" }
            
            Write-Host "Office versions found in registry:" -ForegroundColor Yellow
            foreach ($version in $versions) {
                Write-Host "  Version: $($version.PSChildName)" -ForegroundColor Cyan
            }
        } else {
            Write-Host "No Office registry entries found." -ForegroundColor Red
        }
    }
    catch {
        Write-Host "Error getting version information: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Main script execution
Write-Host "Microsoft Office Management Script" -ForegroundColor Magenta
Write-Host "Educational Use Only - Version 1.0.0" -ForegroundColor Gray
Write-Host "=====================================" -ForegroundColor Magenta

switch ($Action) {
    "CheckStatus" {
        Get-OfficeStatus
    }
    "GetInfo" {
        if ($Product) {
            Get-OfficeInfo -ProductName $Product
        } else {
            Write-Host "Please specify a product name using -Product parameter" -ForegroundColor Yellow
        }
    }
    "ListProducts" {
        Get-OfficeProducts
    }
    "GetVersion" {
        Get-OfficeVersion
    }
    default {
        Write-Host "Invalid action specified. Use: CheckStatus, GetInfo, ListProducts, or GetVersion" -ForegroundColor Red
    }
}

Write-Host "`nScript execution completed." -ForegroundColor Green