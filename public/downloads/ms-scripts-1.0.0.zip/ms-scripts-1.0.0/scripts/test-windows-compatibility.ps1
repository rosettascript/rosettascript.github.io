# Windows Compatibility Test Script
# Tests if the scripts will run properly on Windows

Write-Host "Windows Compatibility Test" -ForegroundColor Cyan
Write-Host "=" * 40 -ForegroundColor Cyan

# Test 1: PowerShell Version
Write-Host "`n1. PowerShell Version Check:" -ForegroundColor Yellow
$psVersion = $PSVersionTable.PSVersion
Write-Host "PowerShell Version: $psVersion" -ForegroundColor White
if ($psVersion.Major -ge 5) {
    Write-Host "✅ PowerShell version is compatible" -ForegroundColor Green
} else {
    Write-Host "❌ PowerShell version is too old (requires 5.1+)" -ForegroundColor Red
}

# Test 2: Windows OS Check
Write-Host "`n2. Windows OS Check:" -ForegroundColor Yellow
$osInfo = Get-WmiObject -Class Win32_OperatingSystem
Write-Host "OS Name: $($osInfo.Caption)" -ForegroundColor White
Write-Host "OS Version: $($osInfo.Version)" -ForegroundColor White
if ($osInfo.Caption -like "*Windows*") {
    Write-Host "✅ Running on Windows" -ForegroundColor Green
} else {
    Write-Host "❌ Not running on Windows" -ForegroundColor Red
}

# Test 3: WMI Availability
Write-Host "`n3. WMI Availability Check:" -ForegroundColor Yellow
try {
    $wmiTest = Get-WmiObject -Class Win32_ComputerSystem -ErrorAction Stop
    Write-Host "✅ WMI is available" -ForegroundColor Green
} catch {
    Write-Host "❌ WMI is not available: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: Registry Access
Write-Host "`n4. Registry Access Check:" -ForegroundColor Yellow
try {
    $regTest = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion" -Name "ProductName" -ErrorAction Stop
    Write-Host "✅ Registry access is available" -ForegroundColor Green
} catch {
    Write-Host "❌ Registry access failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 5: Security Principal
Write-Host "`n5. Security Principal Check:" -ForegroundColor Yellow
try {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    Write-Host "✅ Security Principal is available" -ForegroundColor Green
    Write-Host "Current User: $($currentUser.Name)" -ForegroundColor White
    Write-Host "Is Administrator: $isAdmin" -ForegroundColor White
} catch {
    Write-Host "❌ Security Principal failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 6: Office Detection
Write-Host "`n6. Office Detection Test:" -ForegroundColor Yellow
try {
    $officeProducts = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "*Microsoft Office*" }
    if ($officeProducts) {
        Write-Host "✅ Office products detected:" -ForegroundColor Green
        $officeProducts | ForEach-Object {
            Write-Host "  - $($_.Name)" -ForegroundColor White
        }
    } else {
        Write-Host "⚠️  No Office products detected (this is normal if Office isn't installed)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "❌ Office detection failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 7: Process Management
Write-Host "`n7. Process Management Test:" -ForegroundColor Yellow
try {
    $processTest = Get-Process -Name "powershell" -ErrorAction Stop
    Write-Host "✅ Process management is available" -ForegroundColor Green
    Write-Host "PowerShell processes found: $($processTest.Count)" -ForegroundColor White
} catch {
    Write-Host "❌ Process management failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n" -NoNewline
Write-Host "=" * 40 -ForegroundColor Cyan
Write-Host "Compatibility Test Complete" -ForegroundColor Cyan
Write-Host "=" * 40 -ForegroundColor Cyan

Write-Host "`n📋 Summary:" -ForegroundColor Yellow
Write-Host "If all tests show ✅, the scripts should run properly on this Windows system." -ForegroundColor White
Write-Host "If any tests show ❌, there may be compatibility issues." -ForegroundColor White
