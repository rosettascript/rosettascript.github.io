# Documentation Directory

This directory contains all project documentation and guides.

## 📁 Documentation Files

### Project Documentation
- **`CHANGELOG.md`** - Version history and changes
- **`CONTRIBUTING.md`** - Contribution guidelines
- **`EDUCATIONAL_GUIDE.md`** - Educational examples guide
- **`GITHUB_COMPLIANCE.md`** - GitHub compliance statement

### Documentation Purpose

These documents provide:
- Project history and version tracking
- Guidelines for contributors
- Educational content and examples
- Compliance and legal information
- Security best practices
- Usage instructions

## 📚 Reading Order

1. **README.md** (root) - Main project overview
2. **EDUCATIONAL_GUIDE.md** - Learn about educational examples
3. **CONTRIBUTING.md** - How to contribute
4. **GITHUB_COMPLIANCE.md** - Compliance information
5. **CHANGELOG.md** - Version history

## 🔗 Related Resources

- [PowerShell Documentation](https://docs.microsoft.com/en-us/powershell/)
- [Windows Administration Guide](https://docs.microsoft.com/en-us/windows-server/administration/)
- [Office Deployment Documentation](https://docs.microsoft.com/en-us/deployoffice/)
