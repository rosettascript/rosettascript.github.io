import React from 'react'
import './index.css'

function App() {
  return (
    <div className="App">
      <header>
        <h1>Welcome to Your App</h1>
      </header>
      <main>
        <p>Start building your application!</p>
      </main>
    </div>
  )
}

export default App




